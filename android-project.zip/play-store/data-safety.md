# Respostas sugeridas — Segurança de dados (Google Play)

Esta configuração corresponde ao projeto entregue, que não possui permissão de Internet nem SDKs de analytics/ads.

- O app coleta ou compartilha dados do usuário com o desenvolvedor? **Não**.
- Dados de progresso e anotações: armazenados somente localmente no aparelho; não são transmitidos ao desenvolvedor.
- Publicidade: **Não**.
- Analytics: **Não**.
- Conta/login: **Não**.
- Exclusão: limpar dados ou desinstalar o app remove o armazenamento local.

Revise as respostas no Play Console se você adicionar analytics, login, nuvem, anúncios ou qualquer serviço externo no futuro.
