(function(){
const C='biblia-em-profundidade-concluidos-v1',N='biblia-em-profundidade-devocionais-v1',L='biblia-em-profundidade-ultimo-capitulo-v4';
const DATA=window.BEP_DATA||{allKeys:[],books:[],totalChapters:1189};
function rawGet(k){try{if(window.AndroidStorage&&AndroidStorage.getItem)return AndroidStorage.getItem(k)||'';}catch(e){} try{return localStorage.getItem(k)||''}catch(e){return''}}
function rawSet(k,v){try{if(window.AndroidStorage&&AndroidStorage.setItem){AndroidStorage.setItem(k,v);return true}}catch(e){} try{localStorage.setItem(k,v);return true}catch(e){return false}}
function read(k){try{return JSON.parse(rawGet(k)||'{}')||{}}catch(e){return{}}}
let c=read(C),n=read(N),tim={};
function save(k,v){return rawSet(k,JSON.stringify(v))}
function updateOne(k){let done=!!c[k];document.querySelectorAll('.chapter-complete-check[data-key="'+k+'"]').forEach(x=>{x.checked=done;let t=x.closest('.chapter-complete-label')?.querySelector('.chapter-complete-text');if(t)t.textContent=done?'Este capítulo já foi concluído':'Marcar este capítulo como concluído'});document.querySelectorAll('.chapter-chip[data-completion-key="'+k+'"]').forEach(x=>x.classList.toggle('completed',done))}
function updateGlobal(){let valid=new Set(DATA.allKeys||[]),count=0;Object.keys(c).forEach(k=>{if(valid.has(k)&&c[k])count++});document.querySelectorAll('#completion-progress-text').forEach(e=>e.textContent=count+' de '+DATA.totalChapters);document.querySelectorAll('#completion-progress-fill').forEach(e=>e.style.width=(count/DATA.totalChapters*100)+'%')}
function init(){(DATA.allKeys||[]).forEach(k=>{if(document.querySelector('[data-key="'+k+'"],[data-completion-key="'+k+'"]'))updateOne(k)});document.querySelectorAll('.personal-devotional-input[data-note-key]').forEach(x=>{let k=x.dataset.noteKey;if(Object.prototype.hasOwnProperty.call(n,k))x.value=n[k]});updateGlobal();let h=location.hash;if(h&&h.startsWith('#page-'))rawSet(L,location.href)}
document.addEventListener('change',e=>{if(!e.target.classList.contains('chapter-complete-check'))return;let k=e.target.dataset.key;if(e.target.checked)c[k]=true;else delete c[k];save(C,c);updateOne(k);updateGlobal()});
document.addEventListener('input',e=>{if(!e.target.classList.contains('personal-devotional-input'))return;let k=e.target.dataset.noteKey;n[k]=e.target.value;let s=document.querySelector('[data-note-status="'+k+'"]');if(s)s.textContent='Salvando...';clearTimeout(tim[k]);tim[k]=setTimeout(()=>{if(!n[k])delete n[k];let ok=save(N,n);if(s)s.textContent=ok?'Salvo automaticamente ✓':'Não foi possível salvar.'},350)});
window.addEventListener('hashchange',()=>{if(location.hash.startsWith('#page-'))rawSet(L,location.href)});
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();