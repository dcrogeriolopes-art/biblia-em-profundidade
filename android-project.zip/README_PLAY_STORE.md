# Bíblia em Profundidade — Projeto Android para Google Play

Aplicativo Android nativo com WebView offline contendo os **66 livros e 1.189 capítulos/salmos** da versão revisada v66.

## Identidade
- Nome: Bíblia em Profundidade
- Application ID: `br.com.bibliaemprofundidade.app`
- versionCode: 1
- versionName: 1.0.0
- minSdk: 24
- targetSdk: 36 (Android 16)
- compileSdk: 36

**Atenção:** o Application ID é permanente depois do primeiro cadastro/publicação no Google Play. Altere antes do primeiro envio se desejar outro identificador.

## Conteúdo e privacidade
O estudo fica dentro do app e funciona offline. O projeto não declara permissão `INTERNET`, não inclui publicidade nem analytics. Progresso e devocionais são salvos em `SharedPreferences` por uma ponte JavaScript local.

## Gerar o AAB
1. Abra esta pasta no Android Studio atual.
2. Instale Android SDK Platform 36 e Build Tools 36.0.0 (ou os recomendados pelo Android Studio).
3. O projeto usa Android Gradle Plugin 9.3.0.
4. Para um bundle assinado, copie `upload-key.jks` e `keystore.properties` para a raiz do projeto.
5. Android Studio: **Build > Generate Signed Bundle / APK > Android App Bundle**.
6. O arquivo final normalmente ficará em `app/build/outputs/bundle/release/app-release.aab`.

## Google Play
Novos apps precisam ser enviados em formato **Android App Bundle (AAB)**. Em outubro de 2026, novos apps/atualizações para celulares precisam direcionar o **Android 16 / API 36 ou superior**.

## Arquivos de loja
A pasta `play-store/` contém ícone 512x512, feature graphic 1024x500, textos de listagem, política de privacidade e um rascunho de Segurança de dados.

## Chave de upload
A chave de upload é entregue separadamente do projeto para reduzir o risco de você publicá-la em um repositório. Guarde-a em local seguro e não a compartilhe publicamente.
